import mysql from 'mysql2/promise'

const conexao = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'quiz2'
})

export default conexao