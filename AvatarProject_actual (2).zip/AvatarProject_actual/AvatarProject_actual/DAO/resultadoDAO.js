import conexao from './conexao.js'

export async function inserirResultado({ nome, email, data_nascimento, sexo, resultado }) {

    const [resposta] = await conexao.execute(
        'INSERT INTO resultado (nome, email, data_nascimento, sexo, resultado) VALUES (?, ?, ?, ?, ?)',
        [
            nome,
            email,
            data_nascimento,
            sexo,
            resultado
        ]
    )

    return resposta
}
    export async function
    listarResultado() {
        const [resultados] = await conexao.execute(
            'SELECT * FROM resultado'
        )
        return resultado
    }